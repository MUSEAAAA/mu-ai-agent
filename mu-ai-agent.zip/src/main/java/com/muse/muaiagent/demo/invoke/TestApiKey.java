package com.muse.muaiagent.demo.invoke;

/**
 * 仅用于测试
 */
public interface TestApiKey {
    String API_KEY ="sk-21d51bffc75d460696e94ab5ceec4763";
}
